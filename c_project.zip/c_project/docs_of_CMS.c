/**
 * @file contact_list.c
 * @brief A simple command-line contact list application in C.
 *
 * This program allows users to manage a list of contacts. It provides options
 * to add, delete, view, search, update, and call contacts. Contacts are stored
 * in a file.
 *
 * @author [PM : Raghuveer Yadav , TL : Ashutosh Mishra ,Team Members : Sonu Kumar, Abhishek Sahu, Shashank Tripathi, Ashok Kumar, Rishabh Kesharwani, Vishnu Mishra, Chanchal Saroj, Sushmita Kori]
 * @date [20 Sep 2023 ]
 */
#include <stdbool.h> // Include standard boolean library
#include <stdio.h> // Include standard input/output library
#include <stdlib.h> // Include standard library functions
#include <string.h> // Include string manipulation functions
#include <ctype.h> // Include character manipulation functions
//#include <dos.h> // Contains _dos_getdate (DOS-specific, consider alternatives)
#include <time.h> // Include time-related functions (for potential date use)
//#define SIZE 76800 // Define a constant SIZE for array size

// Structure definition for a contact record
struct contact {
    
    char name[50];
    char num[20];
    char add[50];
    int id;
} ptr;

// Function declarations
void update();
void conlist();
void call();
void del();
void add();
void callone();
void sort();
void search();
void presentTeamProject();
bool phoneValid(char *str);
bool nameValid(char *str);
bool addValid(char *str);
time_t cTime();

FILE *fp, *ft, *fs; // File pointers

char query[20], ch, name[50]; // Global variables
int i,l=0;                   // Global variable
bool s=false;
/**
 * @brief Main function for the contact list application.
 *
 * This function displays a main menu with various options for managing contacts,
 * such as adding, deleting, viewing, searching, sorting, updating, and calling contacts.
 *
 * @return 0 on successful execution.
 */
int main() {
    system("cls"); // Clear the console screen
   // presentTeamProject();
   system("cls"); // Clear the console screen
  
    printf("\n\n\n");
    printf("\t+================================================================+\n");
    printf("\t|\t\t\t===============\t\t\t         |\n");
    printf("\t|\t\t\t   MAIN MENU   \t\t\t         |\n");
    printf("\t|\t\t\t===============\t\t\t         |\n");
    printf("\t+================================================================+\n");
    printf("\n\n\n\t\t\xB2\xB2\xB2\xB2\xB2\t Enter a Choice =>\n");
    printf("\n \t\t\xDB\xDB\xDB\xDB\xB2 1. Open\n");
    printf("\n \t\t\xDB\xDB\xDB\xDB\xB2 2. Exit\n");
     
    switch (getch()) {
          case '1':
            call(); // Call the contact management function
            break;
          default:
            printf("Exit\n");
            break;
    }

    return 0;
}

/**
 * @brief Function to manage contact-related operations.
 *
 * This function displays a menu for managing contacts, including options
 * to add, delete, view, search, update, and call contacts.
 */
void call() {
    system("cls"); // Clear the console screen
    printf("\n");
    printf("\t+================================================================+\n");
    printf("\t|\t\t\t===============\t\t\t         |\n");
    printf("\t|\t\t\t   MAIN MENU   \t\t\t         |\n");
    printf("\t|\t\t\t===============\t\t\t         |\n");
    printf("\t+================================================================+\n");
    printf("\n\n\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2 Enter a Choice  \xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\n");
    printf("\n \t\t\xDB\xDB\xDB\xDB\xB2 1. Call\n");
    printf("\n \t\t\xDB\xDB\xDB\xDB\xB2 2. Add into contact\n");
    printf("\n \t\t\xDB\xDB\xDB\xDB\xB2 3. Delete from contact\n");
    printf("\n \t\t\xDB\xDB\xDB\xDB\xB2 4. View contact\n");
    printf("\n \t\t\xDB\xDB\xDB\xDB\xB2 5. Sorted List contact\n");
    printf("\n \t\t\xDB\xDB\xDB\xDB\xB2 6. Update contact\n");
    printf("\n \t\t\xDB\xDB\xDB\xDB\xB2 7. Search contact\n");
    printf("\n \t\t\xDB\xDB\xDB\xDB\xB2 0. Exit\n");

    switch (getch()) {
        case '1':
        	  system("cls"); // Clear the console screen
            callone(); // Call a specific contact
            break;

        case '2':
        	  system("cls"); // Clear the console screen
            add(); // Add a contact
            break;

        case '3':
        	  system("cls"); // Clear the console screen
            del(); // Delete a contact
            break;

        case '4':
        	  system("cls"); // Clear the console screen
            conlist(); // View the list of contacts
            break;

        case '5':
        	  system("cls"); // Clear the console screen
            sort(); // Sort the list of contacts
            break;

        case '6':
        	  system("cls"); // Clear the console screen
            update(); // Update a contact
            break;

        case '7':
        	  system("cls"); // Clear the console screen
            search(); // Search for a contact
            break;

        default:
            printf("Exit\n");
            main(); // Return to the main menu
            break;
    }
}

// Function to present the team project
void presentTeamProject() {
	system("cls");
	 printf("\n\n\t\t\t\t+===============================+\t\t\t\n");
     printf("\t\t\t\t|   CONTACT MANAGEMENT SYSTEM   |\n");
     printf("\t\t\t\t+===============================+\t\t\t\n");
	
    printf("\n\n \t\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xB2 Team Name: KSS SUPREME CODERS\n\n\n");
    printf("   \t\xDB\xDB\xDB\xDB\xB2 Project Manager: Raghuveer Yadav  \n\n"); // Replace [Project Manager's Name] with the actual PM's name
    printf("   \t\xDB\xDB\xDB\xDB\xB2 Team Leader (TL): Ashutosh Mishra  \n\n"); // Replace [Team Leader's Name] with the actual TL's name
    printf ("   \t\xDB\xDB\xDB\xDB\xB2 Team Memebers (TM):\n\n\t  1. Sonu Kumar :  Sorting \n\t  2. Abhishek Sahu :Update\n\t  3. Shashank Tripathi : Delete \n\t  4. Ashok Kumar :Insert\n\t  5. Rishabh Kesharwani :Sorting\n\t  6. Vishnu Mishra :Delete\n\t  7. Chanchal Saroj:Search\n\t  8.Sushmita Kori :Search\n\n");
 
    
    // Highlight key achievements or features
    printf("\n\t\xDB\xDB\xDB\xDB\xB2 Key Achievements/Features:\n\n");
    printf("\t 1- Add to Contact\n");
    printf("\t 2- Update Contact\n");
    printf("\t 3- Search Contact\n");
    printf("\t 4- Delete from Contact\n");
    printf("\t 5- List of Contact\n");
    printf("\t 6- Sort Contact\n");
    printf("\t 7- Search Contact\n");
    
    // Mention challenges faced and how they were overcome
//    printf("\n\t\xDB\xDB\xDB\xDB\xB2 Challenges Faced and Solutions:\n\n");
//    printf("\t During the project, we encountered challenges such as somebody Understanding of Mission,\n");
//    printf("\n\t but we successfully overcame them by solution.\n");
//    

    // Show project demo or results (if applicable)
    printf("\n\n\t\xDB\xDB\xDB\xDB\xB2 Project Demo:\n\n");
    printf("\t  We will now demonstrate  of our project.\n");
     sleep(125);
     call();
    // Thank the audience and invite questions
    //printf("\nThank you for your attention! We invite any questions or feedback.\n");
}


/**
 * @brief Function to delete a contact.
 *
 * This function allows the user to delete a contact by specifying the name of the contact.
 * It opens the "contact.dll" file, creates a temporary file ("temp.dat"), and copies all contacts
 * except the one to be deleted into the temporary file. The original file is replaced with the
 * temporary file, effectively deleting the specified contact.
 */
 
// time function 

time_t cTime(){
	
   time_t t;
     t=time(NULL);
   return t;
}
void del(void) {
    system("cls"); // Clear the console screen

    fflush(stdin);
    printf("\n\n\t====================================  \t  DELETE A CONTACT   \t  ==================================== \n\n\n  ");
    printf("\n\n");
    printf("\t ======================\tSelect A Choice \t=====================\n\n");
    printf("\n\t => 1. Name :\t");
    printf("\n\t=> 2.  Address :\t");
    printf("\n\t=> 3.  Number :\t");
    
    switch(getch()){
    	
	 case '1':
	 	printf("\n\t => Enter Name :\t");
        gets(name);
	
    fp = fopen("contact.dll", "r"); // Open the file for reading
    ft = fopen("temp.dat", "w"); // Create a temporary file for writing

    while (fread(&ptr, sizeof(ptr), 1, fp) != 0) 
        if (strcmp(name, ptr.name) != 0  )
		     
            fwrite(&ptr, sizeof(ptr), 1, ft); // Copy contacts except the one to delete to the temporary file
    
	    else
		
         printf("\n\t=> ID  : %d\n\t=> Name  : %s\n\t=> contact  : %s\n \t=> Address  : %s\n\n\tThe record is deleted successfully \n", ptr.id, ptr.name, ptr.num, ptr.add);
 
    fclose(fp);
    fclose(ft);

    remove("contact.dll"); // Delete the original file
    rename("temp.dat", "contact.dll"); // Rename the temporary file to the original name
    break;
    
    
     case '2':
	 	printf("\n\t => Enter Address :\t");
        gets(name);
   
	
    fp = fopen("contact.dll", "r"); // Open the file for reading
    ft = fopen("temp.dat", "w"); // Create a temporary file for writing

    while (fread(&ptr, sizeof(ptr), 1, fp) != 0) 
        if (strcmp(name, ptr.add) != 0  )
		     
            fwrite(&ptr, sizeof(ptr), 1, ft); // Copy contacts except the one to delete to the temporary file
        
	    else
		
         printf("\n\t=> ID  : %d\n\t=> Name  : %s\n\t=> contact  : %s\n \t=> Address  : %s\n\n\tThe record is deleted successfully \n", ptr.id, ptr.name, ptr.num, ptr.add);
 
    fclose(fp);
    fclose(ft);

    remove("contact.dll"); // Delete the original file
    rename("temp.dat", "contact.dll"); // Rename the temporary file to the original name
    break;
    
     case '3':
	 	printf("\n\t => Enter Number :\t");
        gets(name);
   
	
    fp = fopen("contact.dll", "r"); // Open the file for reading
    ft = fopen("temp.dat", "w"); // Create a temporary file for writing

    while (fread(&ptr, sizeof(ptr), 1, fp) != 0) 
        if (strcmp(name, ptr.num) != 0  )
		     
            fwrite(&ptr, sizeof(ptr), 1, ft); // Copy contacts except the one to delete to the temporary file
        
	    else
		
         printf("\n\t=> ID  : %d\n\t=> Name  : %s\n\t=> contact  : %s\n \t=> Address  : %s\n\n\tThe record is deleted successfully \n", ptr.id, ptr.name, ptr.num, ptr.add);
 
    fclose(fp);
    fclose(ft);

    remove("contact.dll"); // Delete the original file
    rename("temp.dat", "contact.dll"); // Rename the temporary file to the original name
    break;
	 default:
	 printf("Exit invalid\n");
	 break;
}
    printf("\tDelete any more? (y/n):");
    if (getch() == 'n')
        call(); // Return to the main call() menu
    else {
        system("cls");
        del(); // Allow the user to delete more contacts
    }
}
   




/**
 * @brief Function to search for a contact.
 *
 * This function allows the user to search for a contact by specifying the name of the contact.
 * It reads the name to be searched for, iterates through the contacts in the "contact.dll" file,
 * and displays contact details if a match is found. It provides an option to continue searching.
 */
void search() {
    int found = 0, l;

    system("cls"); // Clear the console screen

    do {
        //found = 0;

printf("\n\n\t<=========================== \t  CONTACT SEARCH \t===========================> \t \n\n\n\n\t\tChoice to search: ");
    printf("\n\n\t\t => 1. Name \t");
    printf("\n\n\t\t => 2. Address \t");
    printf("\n\n\t\t => 3. Number \t\n");
    
    switch(getch()){
    	
	 case '1':
	 	printf("\n\t\t => Enter Name :  ");
       
        fflush(stdin);
        gets(query);
        l = strlen(query);

        fp = fopen("contact.dll", "r"); // Open the file for reading

        system("cls"); // Clear the console screen

        printf("\n\n\t Search result for '%s' \n\t-----------------------------------------\n", query);

        while (fread(&ptr, sizeof(ptr), 1, fp) == 1) {
            for (i = 0; i <= l; i++)
                name[i] = ptr.name[i];
            name[l] = '\0';

            if (strcmp(name, query) == 0) {
                printf("\n\t=> ID\t: %d\n\t=> Name\t: %s\n\t=> Contact\t: %s\n\t=> Address\t: %s\n", ptr.id, ptr.name, ptr.num, ptr.add);
                found++;

//                if (found == 1) {
//                    printf("\t Press any key to continue...");
//                    getch();
//                }
            }
        }
       break;
       case '2':
       		printf("\n\t\t => Enter Address :\t");
       
        fflush(stdin);
        gets(query);
        l = strlen(query);

        fp = fopen("contact.dll", "r"); // Open the file for reading

        system("cls"); // Clear the console screen

        printf("\n\n\t Search result for '%s' \n\t-------------------------------------------\n", query);

        while (fread(&ptr, sizeof(ptr), 1, fp) == 1) {
            for (i = 0; i <= l; i++)
                name[i] = ptr.add[i];
            name[l] = '\0';

            if (strcmp(name, query) == 0) {
                printf("\n\t=> ID\t: %d\n\t=> Name\t: %s\n\t=> Contact\t: %s\n\t=> Address\t: %s\n", ptr.id, ptr.name, ptr.num, ptr.add);
                found++;

//                if (found == 1) {
//                    printf("\t Press any key to continue...");
//                    getch();
//                }
            }
        }
        break;
        case '3':
        		printf("\n\t\t => Enter Number :\t");
       
        fflush(stdin);
        gets(query);
        l = strlen(query);

        fp = fopen("contact.dll", "r"); // Open the file for reading

        system("cls"); // Clear the console screen

        printf("\n\n\t Search result for '%s' \n\t------------------------------------------\n", query);

        while (fread(&ptr, sizeof(ptr), 1, fp) == 1) {
            for (i = 0; i <= l; i++)
                name[i] = ptr.num[i];
            name[l] = '\0';

            if (strcmp(name, query) == 0) {
                printf("\n\t=> ID\t: %d\n\t=> Name\t: %s\n\t=> Contact\t: %s\n\t=> Address\t: %s\n", ptr.id, ptr.name, ptr.num, ptr.add);
                found++;

//                if (found == 1) {
//                    printf("\t Press any key to continue...");
//                    getch();
//                }
            }
        }
        default:
        	printf("\tExit\n");
        	break;
        }
        
        if (found == 0)
            printf("\n\t  No match found!");
        else
            printf("\n\t %d match(s) found!", found);

        fclose(fp); // Close the file

        printf("\n \t Try again?\n\n\t(y/n)\n\t");
               ch=getch();
        if(ch=='n')
            call();
       
          
    } while (ch == 'y');
}

/**
 * @brief Function to display the contact list.
 *
 * This function displays the list of contacts stored in the "contact.dll" file. It reads each contact's
 * details and prints them neatly formatted to the console. After displaying the list, it gives the option
 * to exit to the main menu or continue with other actions.
 */
void conlist() {
    system("cls"); // Clear the console screen

    printf("\n\n\t<============================ \t   CONTACT LIST    \t ============================>\n");
    printf("\n\n\t+-------------------------------------------------------------------------+\n");
    printf("\t|\t ID   \t|  NAME      \t\t|  CONTACT  \t| ADDRESS         |\n");
    printf("\t+-------------------------------------------------------------------------+\n");

    fs = fopen("contact.dll", "r"); // Open the file for reading

    while (fread(&ptr, sizeof(ptr), 1, fs) == 1) {
    
        printf("\t|\t %d  ", ptr.id);
        printf("\t|  %s", ptr.name);
          for(i=0;i<15 -(int)strlen(ptr.name);i++)
		    printf(" "); 
        printf("\t|  %s  ", ptr.num);
        printf("\t| %s ", ptr.add);
         l=strlen(ptr.add);
         for(i=0;i<15-l;i++)
		    printf(" "); 
		printf("|\n");
         printf("\t+-------------------------------------------------------------------------+\n");

    }

    fclose(fs); // Close the file

    printf("\n\t Are you want to exit?\n\n\t(y/n) :\n\t");

    if (getch() == 'y')
        call(); // Return to the main call() menu
    else
        main(); // Return to the main menu
}

/**
 * @brief Function to update a contact's information.
 *
 * This function allows the user to edit the details of an existing contact. It prompts the user to
 * enter the name of the contact to be edited, searches for the contact in the "contact.dll" file,
 * and then allows the user to modify the contact's name, contact number, and address. The updated
 * information is written to a temporary file, and the original file is replaced with the updated data.
 * After updating, it returns to the contact list.
 */
void update() {
    system("cls"); // Clear the console screen
  char add[50] ,con[20];
    fp = fopen("contact.dll", "r"); // Open the file for reading
    ft = fopen("temp.dat", "w"); // Create a temporary file for writing

    fflush(stdin);

     printf("\n\n\t\t<======================= \t EDIT CONTACT  \t  ========================> \t \n\n\n\n\t\tName of contact to Edit  :   ");
scanf("%[^\n]", &name);
    
	
    while (fread(&ptr, sizeof(ptr), 1, fp) == 1) {
        if (strcmp(name, ptr.name) != 0)
            fwrite(&ptr, sizeof(ptr), 1, ft); // Copy contacts except the one to be edited to the temporary file
        else
        {    i=ptr.id;
        	strcpy(name,ptr.name);
        	strcpy(con,ptr.num);
        	strcpy(add,ptr.add);
		}
	}

    printf("\n\t => 1. Name :\t");
    printf("\n\t=> 2.  Number :\t");
    printf("\n\t=> 3.  Address :\t");
    
    switch(getch()){
    	
	 case '1':
	 	printf("\n\t => Enter Name :\t");
       
        fflush(stdin);
          gets(ptr.name);
          strcpy(ptr.add,add);
          strcpy(ptr.num,con);
          ptr.id=i;
    break;
    case '2':
    fflush(stdin);

    printf("\n \t =>Enter Number:");
    scanf("%s", &ptr.num);
    strcpy(ptr.name,name);
    strcpy(ptr.add,add);
     ptr.id=i;
    break;
  case '3':
    fflush(stdin);
    
    printf("\n \t =>Enter Address:");
    scanf("%[^\n]", &ptr.add);
    strcpy(ptr.name,name);
    strcpy(ptr.num,con);
     ptr.id=i;
      break;
    default:
    	printf("Exit\n");
    	break;
    }
    printf("\n");
  
    fwrite(&ptr, sizeof(ptr), 1, ft);

    fclose(fp); // Close the original file
    fclose(ft); // Close the temporary file

    remove("contact.dll"); // Delete the original file
    rename("temp.dat", "contact.dll"); // Rename the temporary file to the original name

    conlist(); // Return to the contact list

 
	
	//	 update(); // Return to the update
}

/**
 * @brief Function to sort contacts by the first letter of their names.
 *
 * This function sorts the contacts stored in the "contact.dll" file based on the first letter
 * of their names. It creates a new file "contact2.txt" to store the sorted contacts temporarily,
 * reads each contact from the original file, and writes them to the temporary file if the first
 * letter of the contact's name matches the current letter (A to Z, both uppercase and lowercase).
 * After sorting, it replaces the original file with the sorted data. It then displays a confirmation
 * message and offers the option to return to the main menu or perform other actions.
 */
void sort() {
    FILE *fp, *tmptr;
    int get = 0;
    int A = 65, a = 97; // ASCII values for 'A' and 'a'

    while (A <= 90) { // Iterate from 'A' to 'Z'
        fp = fopen("contact.dll", "r"); // Open the original file for reading
        if (fp == NULL) {
            printf("File does not Exist:\n");
        }

        tmptr = fopen("contact2.txt", "a"); // Create or open the temporary file for appending
        if (tmptr == NULL) {
            printf("\nFile is not found\n");
        }

        while (fread(&ptr, sizeof(ptr), 1, fp) != 0) {
            get = ptr.name[0];
            if (get == A || get == a) {
                fwrite(&ptr, sizeof(ptr), 1, tmptr); // Write the contact to the temporary file if it matches the current letter
            }
        }

        A++;
        a++;

        fclose(fp); // Close the original file
        fclose(tmptr); // Close the temporary file
    }

    remove("contact.dll"); // Delete the original file
    rename("contact2.txt", "contact.dll"); // Rename the temporary file to the original name

    printf("\n\n \t  Sorted Data   \n");
     
    printf("\n \t DO you want to Exit ?\n\n\t(y/n)\n\t");

    if (getch() == 'y') {
        call(); // Return to the main call() menu
    } else {
        main(); // Return to the main menu
    }
}

/**
 * @brief Function to make a simulated phone call.
 *
 * This function simulates a phone call by accepting a contact number (unused in the current code)
 * and playing a series of beeping sounds using the Beep function. Afterward, it returns to the
 * main call() function.
 */
void callone() {
    int x;
    printf(" \n");
    
     int found = 0, l;

    system("cls"); // Clear the console screen

  

        printf("\n\n\t\t<======================= \t  CONTACT CALL \t  ========================> \t \n\n\n\n\t\tName of contact to Call  :   ");

        fflush(stdin);
        gets(query);
        l = strlen(query);

        fp = fopen("contact.dll", "r"); // Open the file for reading

        system("cls"); // Clear the console screen

        printf("\n\n\t\tCall for '%s' \n", query);

        while (fread(&ptr, sizeof(ptr), 1, fp) == 1) {
            for (i = 0; i <= l; i++)
                name[i] = ptr.name[i];
            name[l] = '\0';

            if (strcmp(name, query) == 0) {
                 
                 found++;
                  
                  for (x = 0; x < 5; x++) {
				              system("cls");
                             Beep(523 + x, 600);
                              printf("\n \t %s  calling....\n",ptr.num);
                              sleep(1);
                           
                      } 
                if (found == 1) {
                	printf("\n\t End Call\n");
                    printf("\n\t Press any key to continue...");
                    
                    getch();
                }
            }
        }

        if (found == 0){
		
            printf("\n\t\t  Can not Contact\n\n\t\t!please add to contact if not\n");
            sleep(3);
            call();
        }
        
          

        fclose(fp); // Close the file
        call();
}

/**
 * @brief Function to add a new contact.
 *
 * This function allows the user to input contact details such as name, ID, contact number, and address.
 * It then appends this information to a file named "contact.dll" and provides an option to add more contacts.
 */
 void add() {
 	
 	 fs = fopen("contact.dll", "r"); // Open the file for reading

    while (fread(&ptr, sizeof(ptr), 1, fs) == 1) {
      
        printf("%d \t", ptr.id);
       
    }

    fclose(fs); // Close the file
    
    system("cls"); // Clear the console screen
     printf("\n\n\t====================================  \t  ADD TO CONTACT   \t  ==================================== \n\n\n");
     
    printf("\n\t=> Enter name  :");
    fflush(stdin);
    gets(ptr.name);
    printf(" \n");
     ptr.id++;
    fflush(stdin);
    printf(" \n");
    printf("\t=> Enter contact number :");
    gets(ptr.num);
    fflush(stdin);
    printf(" \n");
    printf("\t=> Enter address  :");
    gets(ptr.add);
    
    if(phoneValid(ptr.num))
    s=true;
    else
	    printf("\n\tPlease enter valid Indian number\n");
	
    if(nameValid(ptr.name) )
	 s=true;
	else
		printf("\n\tPlease enter name\n");
		
	 if(addValid(ptr.add))
    	s=true;
	 else
	    printf("\n\tPlease enter valid address\n");
	    
	if(s==true){
	
    fp = fopen("contact.dll", "a"); // Open the file for appending
 
    fwrite(&ptr, sizeof(ptr), 1, fp); // Write the contact details to the file
    
    fclose(fp);

    printf("\n\tThe record is successfully saved\n");

    printf("Save any more? (y/n):");
    if (getch() == 'n')
        call(); // Return to the main call() menu
    else {
        system("cls");
        add(); // Allow the user to add more contacts
    }
    printf("Added\n");

    call(); // Return to the main call() menu
}
else{
     printf("\n\tSorry!Can't Insert \n");
     sleep(3);
     add();
 }
}



//mobile number validation

bool phoneValid( char *number) {
    l = strlen(number);


    // the length is exactly 10 characters
    if (l != 10) {
        return false;
    }

    // all characters are digits
    for (i = 0; i < l; i++) {
        if (!isdigit(number[i])) {
            return false;
        }
    }

    // Check first digit is  6 to 9
    if (number[0] < '6' || number[0] > '9') {
        return false;
    }

    return true;
}




// name validation

 bool  nameValid(char *str){
 	 l=strlen(str);
 	if(l==0 || l<2)
 	  s;
 	for(i=0;i<l;i++)
 	   if(str[i]>='0' || str[i]<='9')
 	      s;
 	   else
		s=true;
		
 return s;
		      
 }
 
 //   address validation..
 
  bool  addValid(char *str){
 	l=strlen(str);
 	if(l==0 && l<3)
 	  s;
 	 	for(i=0;i<l;i++)
 	   if(str[i]>='0' || str[i]<='9')
 	      s;
 	   else
		s=true;
			
	return s;  
		      
 }
