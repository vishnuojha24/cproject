
$(document).ready(function(){
  var ind;
  $('.img-thumbnail').click(function(){
   
       var src=$(this).attr('src');
    $(this).attr({"data-bs-toggle":"modal","data-bs-target":"#exampleModal"});

    $('#exampleModal img').attr('src',src);

       var len= $('.img-thumbnail').length;



  });

  var i=0;
  $('#left').click(function(){
        
    var src=$('.img-thumbnail').eq(i).attr('src');

    $('#exampleModal img').attr('src',src);
    i--;
    if(i==0)
        i=20;
  });

  $('#right').click(function(){
   
var src=$('.img-thumbnail').eq(i).attr('src');


$('#exampleModal img').attr('src',src);
i++;
if(i==20)
   i=0;
})




});
 